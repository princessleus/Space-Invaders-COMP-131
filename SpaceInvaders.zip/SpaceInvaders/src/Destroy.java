import java.awt.Color;
import java.awt.Graphics;

public class Destroy extends GraphicsObject {

    public Destroy(double x, double y) {
        super(x, y);
    }

    public void draw(Graphics g) {

    }

}
